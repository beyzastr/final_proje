// Sayfa yüklendiğinde çalışacak ana blok
document.addEventListener("DOMContentLoaded", function() {
    console.log("Vetra Hayvan Barınağı Scripti Başarıyla Yüklendi.");

    // ==================================================================
    // 1. AKORDİYON MENÜ İŞLEVİ (Hizmetler -> Sahiplenme Tıklama)
    // ==================================================================
    const trigger = document.getElementById('sahiplenmeTrigger');
    const submenu = document.getElementById('sahiplenmeSubmenu');

    if (trigger && submenu) {
        trigger.addEventListener('click', function(e) {
            // Hizmetler dropdown menüsünün tamamen kapanmasını engellemek için
            e.stopPropagation(); 
            e.preventDefault();
            
            // Alt menüyü aç/kapat (show sınıfı CSS'de tanımlı olmalı)
            submenu.classList.toggle('show');
            
            // Ok işaretini çevirme (▼ / ▲)
            const icon = this.querySelector('span');
            if (icon) {
                icon.innerText = submenu.classList.contains('show') ? '▲' : '▼';
            }
        });
    }

    // ==================================================================
    // 2. SAHİPLENME KARTLARINI FİLTRELEME İŞLEVİ
    // ==================================================================
    function sahiplenmeKartlariniFiltrele() {
        const urlParams = new URLSearchParams(window.location.search);
        const istenenTur = urlParams.get('tur'); 
        const animalCards = document.querySelectorAll('#animal-cards-container .col-md-4');

        if (animalCards.length > 0 && istenenTur) { 
            animalCards.forEach(card => {
                const kartinTuru = card.getAttribute('data-tur');
                card.style.display = (kartinTuru !== istenenTur) ? 'none' : 'block'; 
            });

            const baslikElementi = document.querySelector('.container.mt-5.mb-5 h1');
            if(baslikElementi) {
                 const turAdi = istenenTur.charAt(0).toUpperCase() + istenenTur.slice(1);
                 baslikElementi.textContent = `🐾 Yuva Arayan ${turAdi}ler`;
            }
        }
    }

    // ==================================================================
    // 3. HİZMET DETAYLARI VERİ YAPISI VE YÜKLEME
    // ==================================================================
    const Hizmetler = {
        muayene: { baslik: "Genel Muayene Hizmetleri", aciklama: "Rutin sağlık kontrolleri hayatidir...", foto: "images/hizmetler_detay1.jpg", detaylar: ["Yıllık Muayene", "Beslenme Planı"] },
        asi: { baslik: "Aşı Takvimi", aciklama: "Aşılar en etkili koruma yoludur...", foto: "images/hizmetler_detay2.jpg", detaylar: ["Kuduz Aşısı", "Parazit Uygulamaları"] },
        mikrocip: { baslik: "Mikroçip Uygulaması", aciklama: "Güvenilir kimlik tespiti sağlar...", foto: "images/hizmetler_detay3.jpg", detaylar: ["Ulusal Veri Tabanı", "Hızlı Uygulama"] },
        laboratuvar: { baslik: "Laboratuvar Analizi", aciklama: "Doğru teşhis anahtardır...", foto: "images/hizmetler_detay4.jpg", detaylar: ["Kan Tahlilleri", "İdrar Analizleri"] },
        goruntuleme: { baslik: "Görüntüleme Hizmetleri", aciklama: "Radyoloji ve Ultrason desteği...", foto: "images/hizmetler_detay5.jpg", detaylar: ["Röntgen", "Ultrasonografi"] },
        endoskopi: { baslik: "Endoskopi", aciklama: "Minimal invaziv teşhis yöntemi...", foto: "images/hizmetler_detay6.jpg", detaylar: ["Biyopsi Alma", "Cisim Çıkarma"] },
        cerrahi: { baslik: "Cerrahi Uygulamalar", aciklama: "Uzman cerrahi operasyonlar...", foto: "images/hizmetler_detay7.jpg", detaylar: ["Kısırlaştırma", "Yumuşak Doku Cerrahisi"] },
        yogunbakim: { baslik: "7/24 Yoğun Bakım", aciklama: "Kritik durumlar için kesintisiz gözetim...", foto: "images/hizmetler_detay8.jpg", detaylar: ["Oksijen Terapisi", "Sürekli Gözetim"] }
    };

    function detaySayfasiIcerikYukle() {
        const urlParams = new URLSearchParams(window.location.search);
        const hizmetKey = urlParams.get('hizmet'); 
        const hizmetData = Hizmetler[hizmetKey];
        
        if (hizmetKey && hizmetData) {
            const baslikEl = document.getElementById('hizmet-baslik');
            const detayAlaniEl = document.getElementById('hizmet-detay-alani');
            
            if (baslikEl) baslikEl.textContent = hizmetData.baslik;
            if (detayAlaniEl) {
                let detayHTML = `<p class="lead">${hizmetData.aciklama}</p>`;
                if (hizmetData.foto) {
                    detayHTML += `<img src="${hizmetData.foto}" class="img-fluid my-4 rounded shadow-sm" alt="${hizmetData.baslik}">`;
                }
                detayHTML += `<h3 class="mt-4">Neler Yapılır?</h3><ul>`;
                hizmetData.detaylar.forEach(detay => detayHTML += `<li>${detay}</li>`);
                detayHTML += `</ul>`;
                detayAlaniEl.innerHTML = detayHTML;
            }
        }
    }

    // ==================================================================
    // 4. İLETİŞİM VE FORM GERİ BİLDİRİMLERİ
    // ==================================================================
    function iletisimFormuDoldur() {
        const urlParams = new URLSearchParams(window.location.search);
        const konuInput = document.getElementById('konu');
        if (!konuInput) return;

        const hayvanAdi = urlParams.get('hayvan');
        const hizmetKonusu = urlParams.get('konu');

        if (hayvanAdi) {
            konuInput.placeholder = `${hayvanAdi} için Sahiplenme Başvurusu (Örnek)`;
        } else if (hizmetKonusu) {
            const temizKonu = hizmetKonusu.charAt(0).toUpperCase() + hizmetKonusu.slice(1);
            konuInput.placeholder = `${temizKonu} Hizmeti İçin Randevu Talebi (Örnek)`;
        }
        konuInput.value = ''; 
    }

    function formGeriBildirimGoster(formId, containerId, successMsg) {
        const form = document.getElementById(formId);
        const container = document.getElementById(containerId);
        if (form && container) {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                if (!form.checkValidity()) {
                    form.classList.add('was-validated');
                    return;
                }
                container.innerHTML = `<div class="alert alert-success mt-3">${successMsg}</div>`;
                form.reset();
                form.classList.remove('was-validated');
            });
        }
    }

    // ==================================================================
    // 5. SAYFA YÜKLEME KONTROLLERİ
    // ==================================================================
    const currentPath = window.location.pathname;

    if (currentPath.includes('sahiplenme.html')) {
        sahiplenmeKartlariniFiltrele();
    } else if (currentPath.includes('hizmet_detay.html')) {
        detaySayfasiIcerikYukle();
    } else if (currentPath.includes('iletisim.html')) {
        iletisimFormuDoldur();
        formGeriBildirimGoster('contactForm', 'alertContainer', 'Teşekkürler! Mesajınız alındı.');
    } else if (currentPath.includes('gonullu.html')) {
        formGeriBildirimGoster('volunteerForm', 'gonulluAlertContainer', 'Başvuru bilgileriniz alınmıştır. En kısa sürede dönüş yapılacaktır.');
    } else if (currentPath.includes('bagis.html')) {
        formGeriBildirimGoster('donationForm', 'donationAlertContainer', 'Teşekkürler! Desteğinizle bir canın hayatına dokunuyorsunuz.');
    }


    // Butonu seçiyoruz
let mybutton = document.getElementById("btn-back-to-top");

// Kullanıcı 20px aşağı indiğinde butonu gösteriyoruz
window.onscroll = function () {
  scrollFunction();
};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// Butona tıklandığında yukarı çıkma fonksiyonu
mybutton.addEventListener("click", backToTop);

function backToTop() {
  window.scrollTo({
    top: 0,
    behavior: "smooth" // Yumuşak kayma efekti
  });
}
});